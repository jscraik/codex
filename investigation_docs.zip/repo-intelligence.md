# Repo Intelligence Report

## 1. System Overview

Codex-rs is an elite-tier Rust monolith operating as an autonomous coding agent and command-line workstation interface. It is secured by a highly sophisticated, multi-platform Bazel build system utilizing custom shadow patches for complete hermeticity. Under the hood, it possesses deep architectural complexity, including over-the-wire shell interception, synthetic ESM persistent REPLs, and sandbox containment. While it exhibits brilliant low-level systems engineering and execution routing, the repository's application tier is currently strained by massive TUI monoliths ("God Modules") and loose serialization contracts in its V2 protocol.

---

## 2. Golden Nuggets (Ranked)

| Rank | Nugget | Why it Matters | Reusability |
|------|--------|----------------|------------|
| 1 | Over-the-Wire Exec Interception | Pauses CLI tasks securely via FD passing for external human-in-the-loop approval, enabling zero-trust without custom terminal UX. | High |
| 2 | Persistent JS REPL Kernel Cells | Uses AST hoisting & SyntheticModules to create a persistent Node.js REPL effect from isolated executions without global namespace pollution. | High |
| 3 | Shadow Build-System Patching | 25+ local patches (e.g. LLVM, Abseil) guarantee strictly hermetic cross-compilation across Windows/macOS/Linux. | Low |
| 4 | Fuzzy Patch Seeking Algorithm | Progressively relaxes diff matching (trim &rarr; right-strip &rarr; Unicode normalization) to drastically increase AI diff application success rates. | High |
| 5 | Zero-Trust Shell Heuristics | Parses shell commands deeply into ASTs to guarantee execution idempotency automatically, rather than relying on brittle whitelists. | Medium |
| 6 | MitM TLS Proxy with On-the-fly Certs | Embedded proxy intercepting CONNECT traffic & minting leaf certs natively in memory using rcgen for transparent policy enforcement. | Medium |
| 7 | Inventory-based Compile Gating | Procedural macro (`#[derive(ExperimentalApi)]`) that decentralizes feature-flag tracking using `inventory::submit!` block generation. | High |
| 8 | Multi-Plat PTY Unified Interface | A single `ProcessHandle` protecting product layers from the severe complexities of resolving Windows ConPTY vs POSIX PTY lifecycle quirks. | High |
| 9 | Terminal & Env Injection Trait | Lifts `std::env` into a "Virtual OS" trait mapping, providing Phantom UI rendering surfaces during unit tests. | High |
| 10 | Unified Arg0 Process Dispatcher | Single-binary multiplexer inspecting `argv[0]` symlinks to boot vastly different toolchains (sandbox, patching utility) from one payload. | High |

---

## 3. Key Strengths

- **Hardened Cross-Platform Hermeticity:** The build pipeline is rigorously sealed. Code that compiles successfully under Bazel is guaranteed to execute identically across all target platforms, circumventing standard Rust/C++ ecosystem toolchain mismatches.
- **Deep Execution Safety Controls:** Agent autonomy is tightly constrained through in-memory proxy interception, Linux Landlock capabilities, and the AST-aware safety heuristic engine protecting the file system.
- **Forward-Compatible Configuration Resilience:** Configuration structs use default `Unknown` parsing variants. This enables legacy agent runtimes to degrade gracefully rather than fail destructively when interacting with newer command schemas.
- **Resilient AI Feedback Loops:** Instead of punishing agents for minor typographic errors (e.g. smart-quotes), local fuzzy-seeking algorithms automatically normalize unicode characters and whitespace to forcibly apply patches successfully.

---

## 4. Key Risks

- **Critical TUI Monoliths (God Modules):** The `tui/src/chatwidget.rs` (11k LOC) and `app.rs` (10k LOC) files have ballooned into un-reviewable, overlapping state machines. Feature velocity is severely threatened by merge conflicts and cognitive overload in this layer.
- **Protocol Serialization Drift:** The systemic usage of `skip_serializing_if = "Option::is_none"` throughout the `v2.rs` JSON payload logic causes structural schema mismatches with frontend clients, confusing type-safe `null` values with missing keys.
- **Ambiguous Internal API Boundaries:** Deep usage of opaque positional primitives (e.g., `(true, false, None)`) in central logic instead of fully expressive enums limits self-documentation, resulting in higher friction onboarding.

---

## 5. Patterns & Anti-Patterns

**Pattern: Injected Context Traits for UI Components**
- *Evidence:* Abstracting `std::env` behind an `Environment` interface for checking pseudo-terminal properties.
- *Implication:* Provides safe execution context substitution (e.g. Ghostty vs. Warp checks) directly in unit tests without OS spoofing.

**Pattern: Decentralized Metadata Registration**
- *Evidence:* The `ExperimentalApi` macro dynamically logging new payload fields to global inventory variables at compile time.
- *Implication:* Teams can drop cleanly annotated feature structs anywhere in the code without navigating a central registry module file.

**Anti-Pattern: The Big Ball of Mud**
- *Evidence:* The `ChatWidget` and `App` architectures housing simultaneous networking, styling, routing, and user event logic.
- *Implication:* Extreme coupling that makes testing and parallel team development increasingly brittle.

**Anti-Pattern: Implicit Wire Pruning**
- *Evidence:* Bypassing standard JSON standards natively (not serializing absent None variables).
- *Implication:* Generates brittle generated API typescript contracts.

---

## 6. Developer Experience Insights

- **Observation:** Routine testing demands strict runfiles abstraction tools like `codex_utils_cargo_bin` rather than native path assertions.
  **Effect:** Engineers native to standard Cargo ecosystems will repeatedly break the Bazel caching engine if not aggressively monitored.
- **Observation:** `Style::default()` instances are frequently hand-allocated instead of leveraging the ergonomic `Stylize` `.red().bold()` chain methods in `ratatui`.
  **Effect:** Visual inconsistency and bloated rendering functions.
- **Observation:** Highly aggressive Rust formatting and Lints applied via `just fix`.
  **Effect:** Excellent baseline consistency, though the slow execution times of workspace-wide validation builds introduces friction to the inner loop.

---

## 7. Signal Summary

- **Top 3 Nuggets:** OTW Exec Interception, Persistent ESM REPL Kernel Cells, and the Fuzzy Patch Normalisation algorithm.
- **Top 3 Risks:** The `chatwidget.rs` 11k LOC God Module monolith, missing `null`-field V2 protocol serialization, and positional boolean API signatures.
- **Most Reusable Pattern:** The AST-aware Zero-Trust structural command parser for establishing automated command idempotency without manual blacklisting.
